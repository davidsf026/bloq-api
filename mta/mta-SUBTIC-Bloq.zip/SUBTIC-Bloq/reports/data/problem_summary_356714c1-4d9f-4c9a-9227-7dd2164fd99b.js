MIGRATION_ISSUES_DETAILS["356714c1-4d9f-4c9a-9227-7dd2164fd99b"] = [
{description: "<p>Spring application properties detected<\/p>", ruleID: "configuration-management-0200", issueName: "Spring application properties detected",
problemSummaryID: "356714c1-4d9f-4c9a-9227-7dd2164fd99b", files: [
{l:"<a class='' href='application_properties.html?project=835592'>application.properties<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("356714c1-4d9f-4c9a-9227-7dd2164fd99b");