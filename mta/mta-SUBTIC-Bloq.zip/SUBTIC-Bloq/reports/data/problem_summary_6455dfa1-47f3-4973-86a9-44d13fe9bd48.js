MIGRATION_ISSUES_DETAILS["6455dfa1-47f3-4973-86a9-44d13fe9bd48"] = [
{description: "<p>This XML file could not be parsed.<\/p>", ruleID: "DiscoverXmlFilesRuleProvider_5", issueName: "Unparsable XML File",
problemSummaryID: "6455dfa1-47f3-4973-86a9-44d13fe9bd48", files: [
{l:"<a class='' href='message_xhtml.html?project=835592'>paginas/message.xhtml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("6455dfa1-47f3-4973-86a9-44d13fe9bd48");