MIGRATION_ISSUES_DETAILS["80c22e8c-352c-4491-9807-a1752fbdaf7f"] = [
{description: "<p>Replace <code>beans_1_1.xsd<\/code> with <code>beans_3_0.xsd<\/code> and update the version attribute to <code>&quot;3.0&quot;<\/code><\/p>", ruleID: "javaee-to-jakarta-namespaces-00006", issueName: "Replace the Java EE XSD with the Jakarta equivalent",
problemSummaryID: "80c22e8c-352c-4491-9807-a1752fbdaf7f", files: [
{l:"<a class='' href='beans_xml.html?project=835592'>META-INF/beans.xml<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://jakarta.ee/xml/ns/jakartaee/#9", t:"Jakarta XML Schemas"},
]},
];
onProblemSummaryLoaded("80c22e8c-352c-4491-9807-a1752fbdaf7f");