MIGRATION_ISSUES_DETAILS["f739794b-831e-4dd3-a50d-df4cea8adced"] = [
{description: "<p>In a cloud environment, a restart can wipe out HTTP session data in the memory of a running container.<\/p><p>Recommendation: Store HTTP session data in a cache backing service or a remote data grid.<\/p><p>A remote data grid has the following benefits:<\/p>\n<ul>\n <li>The application is more scaleable and elastic.<\/li>\n <li>The application can survive EAP node failures because a JVM failure does not cause session data loss.<\/li>\n <li>Session data can be shared by multiple applications.<\/li>\n<\/ul>", ruleID: "session-00001", issueName: "HTTP Session data storage",
problemSummaryID: "f739794b-831e-4dd3-a50d-df4cea8adced", files: [
{l:"<a class='' href='LoginCertServlet_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.web.security.LoginCertServlet<\/a>", oc:"3"},
{l:"<a class='' href='FiltroAutorizacao_java.html?project=835592'>ssa.control.servlet.FiltroAutorizacao<\/a>", oc:"1"},
{l:"<a class='' href='FiltroCertificado_java.html?project=835592'>ssa.control.servlet.FiltroCertificado<\/a>", oc:"2"},
], resourceLinks: [
{h:"https://access.redhat.com/documentation/en-us/red_hat_jboss_enterprise_application_platform/7.3/html-single/configuration_guide/index#jdg_externalize_http_sessions", t:"JBoss EAP: Externalize HTTP Sessions to Red Hat Data Grid"},
{h:"https://access.redhat.com/documentation/en-us/red_hat_data_grid/8.0/html-single/running_data_grid_on_openshift/index", t:"Running Data Grid on OpenShift"},
{h:"https://12factor.net/processes", t:"Twelve-Factor App: Processes"},
{h:"https://12factor.net/backing-services", t:"Twelve-Factor App: Backing services"},
]},
];
onProblemSummaryLoaded("f739794b-831e-4dd3-a50d-df4cea8adced");