MIGRATION_ISSUES_DETAILS["d78ea28f-57f6-48a8-b4be-a32bfe0c7e92"] = [
{description: "<p>The application embeds a Spring DI library.<\/p>", ruleID: "embedded-framework-08200", issueName: "Embedded framework - Spring DI",
problemSummaryID: "d78ea28f-57f6-48a8-b4be-a32bfe0c7e92", files: [
{l:"SUBTIC-Bloq.ear/lib/spring-beans-3.0.6.RELEASE.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("d78ea28f-57f6-48a8-b4be-a32bfe0c7e92");