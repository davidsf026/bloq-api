MIGRATION_ISSUES_DETAILS["b94df0a9-fae9-45fa-9b99-296b23cf3f16"] = [
{description: "<p>The application embeds a JDBC library.<\/p>", ruleID: "embedded-framework-libraries-04000", issueName: "Embedded library - JDBC",
problemSummaryID: "b94df0a9-fae9-45fa-9b99-296b23cf3f16", files: [
{l:"SUBTIC-Bloq.ear/lib/ojdbc7-12.1.0.2.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("b94df0a9-fae9-45fa-9b99-296b23cf3f16");