MIGRATION_ISSUES_DETAILS["7e63131f-2144-4ff8-8e4f-ece2da60777f"] = [
{description: "<p><code>beans_1_1.xsd<\/code>: In the root tag, replace the <code>version<\/code> attribute value with <code>3.0<\/code><\/p>", ruleID: "javaee-to-jakarta-namespaces-00035", issueName: "Replace the Java EE version with the Jakarta equivalent",
problemSummaryID: "7e63131f-2144-4ff8-8e4f-ece2da60777f", files: [
{l:"<a class='' href='beans_xml.html?project=835592'>META-INF/beans.xml<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://jakarta.ee/xml/ns/jakartaee/#9", t:"Jakarta XML Schemas"},
]},
];
onProblemSummaryLoaded("7e63131f-2144-4ff8-8e4f-ece2da60777f");