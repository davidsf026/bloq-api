MIGRATION_ISSUES_DETAILS["e60f94f0-88fa-4d0a-890e-09accbbf6dd6"] = [
{description: "<p>The application embeds a JBoss logging library.<\/p>", ruleID: "logging-usage-00080", issueName: "Embedded library - JBoss logging",
problemSummaryID: "e60f94f0-88fa-4d0a-890e-09accbbf6dd6", files: [
{l:"SUBTIC-Bloq.ear/lib/jboss-logging-3.3.0.Final.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("e60f94f0-88fa-4d0a-890e-09accbbf6dd6");