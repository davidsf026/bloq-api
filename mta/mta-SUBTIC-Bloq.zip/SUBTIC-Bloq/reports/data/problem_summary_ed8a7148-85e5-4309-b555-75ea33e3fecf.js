MIGRATION_ISSUES_DETAILS["ed8a7148-85e5-4309-b555-75ea33e3fecf"] = [
{description: "<p>An application running inside a container could lose access to a file in local storage.<\/p><p>Recommendations<\/p><p>The following recommendations depend on the function of the file in local storage:<\/p>\n<ul>\n <li>Logging: Log to standard output and use a centralized log collector to analyze the logs.<\/li>\n <li>Caching: Use a cache backing service.<\/li>\n <li>Configuration: Store configuration settings in environment variables so that they can be updated without code changes.<\/li>\n <li>Data storage: Use a database backing service for relational data or use a persistent data storage system.<\/li>\n <li>Temporary data storage: Use the file system of a running container as a brief, single-transaction cache.<\/li>\n<\/ul>", ruleID: "local-storage-00003", issueName: "File system - File path URL",
problemSummaryID: "ed8a7148-85e5-4309-b555-75ea33e3fecf", files: [
{l:"<a class='' href='certificadoDigital_properties.html?project=835592'>certificadoDigital.properties<\/a>", oc:"1"},
{l:"<a class='' href='certificadoDigital_properties.10.html?project=835592'>certificadoDigital.properties<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://12factor.net/config", t:"Twelve-Factor App: Config"},
{h:"https://docs.openshift.com/container-platform/4.5/logging/cluster-logging.html", t:"OpenShift Container Platform: Understanding cluster logging"},
{h:"https://12factor.net/logs", t:"Twelve-Factor App: Logs"},
{h:"https://docs.openshift.com/container-platform/4.5/builds/creating-build-inputs.html#builds-input-secrets-configmaps_creating-build-inputs", t:"OpenShift Container Platform: Input secrets and ConfigMaps"},
{h:"https://12factor.net/backing-services", t:"Twelve-Factor App: Backing services"},
{h:"https://docs.openshift.com/container-platform/4.5/storage/understanding-persistent-storage.html", t:"OpenShift Container Platform: Understanding persistent storage"},
]},
];
onProblemSummaryLoaded("ed8a7148-85e5-4309-b555-75ea33e3fecf");