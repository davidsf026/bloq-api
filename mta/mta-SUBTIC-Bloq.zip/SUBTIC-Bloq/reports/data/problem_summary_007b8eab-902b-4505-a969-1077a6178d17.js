MIGRATION_ISSUES_DETAILS["007b8eab-902b-4505-a969-1077a6178d17"] = [
{description: "<p>Update the group dependency by replacing the <code>javax.servlet<\/code> groupId with <code>jakarta.servlet<\/code><\/p>", ruleID: "javax-to-jakarta-dependencies-00001", issueName: "javax.servlet groupId has been replaced by jakarta.servlet",
problemSummaryID: "007b8eab-902b-4505-a969-1077a6178d17", files: [
{l:"<a class='' href='pom_xml.7.html?project=835592'>META-INF/maven/ssa/ssa-core/pom.xml<\/a>", oc:"2"},
], resourceLinks: [
{h:"https://jakarta.ee/", t:"Jakarta EE"},
]},
];
onProblemSummaryLoaded("007b8eab-902b-4505-a969-1077a6178d17");