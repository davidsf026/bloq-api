MIGRATION_ISSUES_DETAILS["41cefac6-cf18-476d-823c-bd1147afce64"] = [
{description: "<p>Add the <code>jakarta.annotation<\/code> dependency to your application\'s <code>pom.xml<\/code>.<\/p><p><code>&lt;groupId&gt;jakarta.annotation&lt;/groupId&gt;<\/code><\/p><p><code>&lt;artifactId&gt;jakarta.annotation-api&lt;/artifactId&gt;<\/code><\/p>", ruleID: "removed-javaee-modules-00020", issueName: "The java.annotation (Common Annotations) module has been removed from OpenJDK 11",
problemSummaryID: "41cefac6-cf18-476d-823c-bd1147afce64", files: [
{l:"<a class='' href='FuncionarioController_java.html?project=835592'>br.gov.rj.fazenda.bloqueio.controller.FuncionarioController<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://www.oracle.com/java/technologies/javase/11-relnote-issues.html#JDK-8190378", t:"Removed Java EE modules"},
]},
];
onProblemSummaryLoaded("41cefac6-cf18-476d-823c-bd1147afce64");