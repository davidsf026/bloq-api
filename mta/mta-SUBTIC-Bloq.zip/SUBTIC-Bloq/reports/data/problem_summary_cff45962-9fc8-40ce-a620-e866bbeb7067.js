MIGRATION_ISSUES_DETAILS["cff45962-9fc8-40ce-a620-e866bbeb7067"] = [
{description: "<p>If the <code>SessionFactory<\/code> is built via Hibernate’s native bootstrapping and <code>org.hibernate.HibernateException<\/code> or a subclass is referenced by the application then set <code>hibernate.native_exception_handling_51_compliance<\/code> configuration property to <code>true<\/code>.<\/p>", ruleID: "hibernate51-53-00300", issueName: "Hibernate 5.3 - Exception Handling",
problemSummaryID: "cff45962-9fc8-40ce-a620-e866bbeb7067", files: [
{l:"<a class='' href='HibernateFilter_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.model.util.HibernateFilter<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://access.redhat.com/documentation/en-us/red_hat_jboss_enterprise_application_platform/7.2/html-single/migration_guide/#exception_handling_changes_between_51_53", t:"Red Hat JBoss EAP 7.2: Migrating from Hibernate ORM 5.1 to Hibernate ORM 5.3"},
]},
];
onProblemSummaryLoaded("cff45962-9fc8-40ce-a620-e866bbeb7067");