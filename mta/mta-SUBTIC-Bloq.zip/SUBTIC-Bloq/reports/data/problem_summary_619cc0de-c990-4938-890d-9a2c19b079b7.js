MIGRATION_ISSUES_DETAILS["619cc0de-c990-4938-890d-9a2c19b079b7"] = [
{description: "<p>The application embeds the JUnit framework.<\/p>", ruleID: "test-frameworks-sauge-00370", issueName: "Embedded framework - JUnit",
problemSummaryID: "619cc0de-c990-4938-890d-9a2c19b079b7", files: [
{l:"SUBTIC-Bloq.ear/lib/junit-4.9.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("619cc0de-c990-4938-890d-9a2c19b079b7");