MIGRATION_ISSUES_DETAILS["650044b8-99de-4033-bc65-4a67c89033ac"] = [
{description: "<p>The application embeds a PrimeFaces library.<\/p>", ruleID: "mvc-02400", issueName: "Embedded library - PrimeFaces",
problemSummaryID: "650044b8-99de-4033-bc65-4a67c89033ac", files: [
{l:"SUBTIC-Bloq.ear/lib/primefaces-6.1.jar", oc:"1"},
{l:"SUBTIC-Bloq.ear/lib/primefaces-extensions-6.1.1.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("650044b8-99de-4033-bc65-4a67c89033ac");