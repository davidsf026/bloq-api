MIGRATION_ISSUES_DETAILS["2312d8d8-a837-4466-98af-163b1906dace"] = [
{description: "<p>The application embeds a Simple Logging Facade for Java (SLJ4J) library.<\/p>", ruleID: "logging-usage-00030", issueName: "Embedded library - SLF4J",
problemSummaryID: "2312d8d8-a837-4466-98af-163b1906dace", files: [
{l:"SUBTIC-Bloq.ear/lib/slf4j-api-1.7.25.jar", oc:"1"},
{l:"SUBTIC-Bloq.ear/lib/slf4j-log4j12-1.7.5.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("2312d8d8-a837-4466-98af-163b1906dace");