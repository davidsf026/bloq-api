MIGRATION_ISSUES_DETAILS["376992ba-de78-444c-b357-b2f754e730e9"] = [
{description: "<p>Maven Project Object Model (POM) File<\/p>", ruleID: "DiscoverMavenProjectsRuleProvider_1", issueName: "Maven POM (pom.xml)",
problemSummaryID: "376992ba-de78-444c-b357-b2f754e730e9", files: [
{l:"<a class='' href='pom_xml.html?project=835592'>META-INF/maven/br.gov.rj.fazenda/SUBTIC-Bloq-ear/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.69.html?project=835592'>META-INF/maven/br.gov.rj.fazenda/SUBTIC-Bloq-web/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.7.html?project=835592'>META-INF/maven/ssa/ssa-core/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.5.html?project=835592'>META-INF/maven/br.gov.rj.fazenda/SUBTIC-Bloq-business/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.18.html?project=835592'>META-INF/maven/br.gov.sefazrj.sati.sefazwork/SATI-Sefazwork-config/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.2.html?project=835592'>META-INF/maven/br.gov.sefazrj.sati.sefazwork/SATI-Sefazwork-web/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.19.html?project=835592'>META-INF/maven/br.gov.rj.fazenda/SUAF-MailClient/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.73.html?project=835592'>META-INF/maven/br.gov.sefazrj.sati.sefazwork/SATI-Sefazwork-business/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.66.html?project=835592'>META-INF/maven/br.gov.sefazrj.sati.sefazwork/SATI-Sefazwork-controller/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.53.html?project=835592'>META-INF/maven/org.primefaces.themes/afterwork/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.64.html?project=835592'>META-INF/maven/br.gov.sefazrj.sati.sefazwork/SATI-Sefazwork-services/pom.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("376992ba-de78-444c-b357-b2f754e730e9");