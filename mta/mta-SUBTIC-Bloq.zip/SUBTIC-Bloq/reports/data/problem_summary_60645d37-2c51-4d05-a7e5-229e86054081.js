MIGRATION_ISSUES_DETAILS["60645d37-2c51-4d05-a7e5-229e86054081"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "60645d37-2c51-4d05-a7e5-229e86054081", files: [
{l:"<a class='' href='web_xml.html?project=835592'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("60645d37-2c51-4d05-a7e5-229e86054081");