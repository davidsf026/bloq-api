MIGRATION_ISSUES_DETAILS["851d7816-5c68-4d3c-8e4f-3f77f790d61a"] = [
{description: "<p>The application uses Java EE Application Deployment.<\/p>", ruleID: "javaee-technology-usage-00060", issueName: "Java EE Application Deployment",
problemSummaryID: "851d7816-5c68-4d3c-8e4f-3f77f790d61a", files: [
{l:"SUBTIC-Bloq.ear", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("851d7816-5c68-4d3c-8e4f-3f77f790d61a");