MIGRATION_ISSUES_DETAILS["528bde10-d924-4669-a40e-62749dabd5f2"] = [
{description: "<p>The application embeds the Hibernate framework.<\/p>", ruleID: "embedded-framework-01500", issueName: "Embedded framework - Hibernate",
problemSummaryID: "528bde10-d924-4669-a40e-62749dabd5f2", files: [
{l:"SUBTIC-Bloq.ear/lib/hibernate-entitymanager-5.2.10.Final.jar", oc:"1"},
{l:"SUBTIC-Bloq.ear/lib/hibernate-core-5.2.10.Final.jar", oc:"1"},
{l:"SUBTIC-Bloq.ear/lib/hibernate-commons-annotations-5.0.1.Final.jar", oc:"1"},
{l:"SUBTIC-Bloq.ear/lib/hibernate-jpa-2.1-api-1.0.0.Final.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("528bde10-d924-4669-a40e-62749dabd5f2");