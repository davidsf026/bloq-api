MIGRATION_ISSUES_DETAILS["4230f51a-32d4-4ffe-af95-84d85648233f"] = [
{description: "<p>Replace the <code>javax.ws<\/code> import statement with <code>jakarta.ws<\/code><\/p>", ruleID: "javax-to-jakarta-import-00001", issueName: "javax.ws has been replaced by jakarta.ws",
problemSummaryID: "4230f51a-32d4-4ffe-af95-84d85648233f", files: [
{l:"<a class='' href='ClientHttpPost_java.html?project=835592'>br.gov.rj.fazenda.client.suaf.mailclient.ClientHttpPost<\/a>", oc:"5"},
{l:"<a class='' href='RestClient_java.html?project=835592'>br.gov.rj.fazenda.client.suaf.mailclient.RestClient<\/a>", oc:"3"},
{l:"<a class='' href='MailClient_java.html?project=835592'>br.gov.rj.fazenda.client.suaf.mailclient.MailClient<\/a>", oc:"1"},
{l:"<a class='' href='ClientHttp_java.html?project=835592'>br.gov.rj.fazenda.client.suaf.mailclient.ClientHttp<\/a>", oc:"2"},
], resourceLinks: [
{h:"https://jakarta.ee/", t:"Jakarta EE"},
]},
];
onProblemSummaryLoaded("4230f51a-32d4-4ffe-af95-84d85648233f");