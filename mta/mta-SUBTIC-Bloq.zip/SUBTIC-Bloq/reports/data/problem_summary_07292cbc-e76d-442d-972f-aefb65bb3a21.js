MIGRATION_ISSUES_DETAILS["07292cbc-e76d-442d-972f-aefb65bb3a21"] = [
{description: "<p>Replace the <code>javax.faces<\/code> import statement with <code>jakarta.faces<\/code><\/p>", ruleID: "javax-to-jakarta-import-00001", issueName: "javax.faces has been replaced by jakarta.faces",
problemSummaryID: "07292cbc-e76d-442d-972f-aefb65bb3a21", files: [
{l:"<a class='' href='FuncionarioController_java.html?project=835592'>br.gov.rj.fazenda.bloqueio.controller.FuncionarioController<\/a>", oc:"2"},
{l:"<a class='' href='Mensagem_java.72.html?project=835592'>br.gov.rj.fazenda.bloqueio.util.Mensagem<\/a>", oc:"2"},
], resourceLinks: [
{h:"https://jakarta.ee/", t:"Jakarta EE"},
]},
];
onProblemSummaryLoaded("07292cbc-e76d-442d-972f-aefb65bb3a21");