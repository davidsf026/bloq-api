MIGRATION_ISSUES_DETAILS["bc0f1649-7052-4fce-a7a4-f585d05c4ea9"] = [
{description: "<p>The application embeds an Oracle DB driver.<\/p>", ruleID: "database-02100", issueName: "Embedded Oracle DB Driver",
problemSummaryID: "bc0f1649-7052-4fce-a7a4-f585d05c4ea9", files: [
{l:"SUBTIC-Bloq.ear/lib/ojdbc7-12.1.0.2.jar", oc:"1"},
], resourceLinks: [
{h:"https://access.redhat.com/articles/111663", t:"Red Hat JBoss Enterprise Application Platform (EAP) 6 Supported Configurations"},
{h:"https://access.redhat.com/articles/2026253", t:"Red Hat JBoss Enterprise Application Platform (EAP) 7 Supported Configurations"},
]},
];
onProblemSummaryLoaded("bc0f1649-7052-4fce-a7a4-f585d05c4ea9");