MIGRATION_ISSUES_DETAILS["13b31195-d6d0-4105-8276-b76f643669fc"] = [
{description: "<p>Replace the <code>javax.persistence<\/code> import statement with <code>jakarta.persistence<\/code><\/p>", ruleID: "javax-to-jakarta-import-00001", issueName: "javax.persistence has been replaced by jakarta.persistence",
problemSummaryID: "13b31195-d6d0-4105-8276-b76f643669fc", files: [
{l:"<a class='' href='FuncionarioDAO_java.html?project=835592'>br.gov.rj.fazenda.bloqueio.dao.FuncionarioDAO<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://jakarta.ee/", t:"Jakarta EE"},
]},
];
onProblemSummaryLoaded("13b31195-d6d0-4105-8276-b76f643669fc");