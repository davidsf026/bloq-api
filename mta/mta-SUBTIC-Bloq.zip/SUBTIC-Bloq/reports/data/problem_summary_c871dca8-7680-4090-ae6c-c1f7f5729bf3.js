MIGRATION_ISSUES_DETAILS["c871dca8-7680-4090-ae6c-c1f7f5729bf3"] = [
{description: "<p>The application uses Common Annotations<\/p>", ruleID: "javaee-technology-usage-00080", issueName: "Common Annotations",
problemSummaryID: "c871dca8-7680-4090-ae6c-c1f7f5729bf3", files: [
{l:"<a class='' href='FuncionarioController_java.html?project=835592'>br.gov.rj.fazenda.bloqueio.controller.FuncionarioController<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("c871dca8-7680-4090-ae6c-c1f7f5729bf3");