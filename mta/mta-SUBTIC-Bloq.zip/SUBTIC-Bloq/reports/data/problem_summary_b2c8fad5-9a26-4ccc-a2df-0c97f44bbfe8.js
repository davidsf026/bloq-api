MIGRATION_ISSUES_DETAILS["b2c8fad5-9a26-4ccc-a2df-0c97f44bbfe8"] = [
{description: "<p>The application uses Java Servlets<\/p>", ruleID: "javaee-technology-usage-00120", issueName: "Java Servlet",
problemSummaryID: "b2c8fad5-9a26-4ccc-a2df-0c97f44bbfe8", files: [
{l:"<a class='' href='FiltroAutorizacao_java.html?project=835592'>ssa.control.servlet.FiltroAutorizacao<\/a>", oc:"1"},
{l:"<a class='' href='DesautorizadoTag_java.html?project=835592'>ssa.view.taglib.DesautorizadoTag<\/a>", oc:"1"},
{l:"<a class='' href='BloqueioFilter_java.html?project=835592'>br.gov.rj.fazenda.bloqueio.filtro.BloqueioFilter<\/a>", oc:"1"},
{l:"<a class='' href='LoginServlet_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.web.security.LoginServlet<\/a>", oc:"1"},
{l:"<a class='' href='SSASessaoTag_java.html?project=835592'>ssa.view.taglib.SSASessaoTag<\/a>", oc:"1"},
{l:"<a class='' href='FiltroCertificado_java.html?project=835592'>ssa.control.servlet.FiltroCertificado<\/a>", oc:"1"},
{l:"<a class='' href='LoginCertServlet_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.web.security.LoginCertServlet<\/a>", oc:"1"},
{l:"<a class='' href='LogoutServlet_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.web.security.LogoutServlet<\/a>", oc:"1"},
{l:"<a class='' href='SSAPropertyTag_java.html?project=835592'>ssa.view.taglib.SSAPropertyTag<\/a>", oc:"1"},
{l:"<a class='' href='AutorizadoTag_java.html?project=835592'>ssa.view.taglib.AutorizadoTag<\/a>", oc:"1"},
{l:"<a class='' href='HibernateContextListener_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.web.listener.HibernateContextListener<\/a>", oc:"1"},
{l:"<a class='' href='HibernateFilter_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.model.util.HibernateFilter<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("b2c8fad5-9a26-4ccc-a2df-0c97f44bbfe8");