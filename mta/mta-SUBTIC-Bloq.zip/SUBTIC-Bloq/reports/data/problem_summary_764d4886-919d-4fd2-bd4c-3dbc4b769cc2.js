MIGRATION_ISSUES_DETAILS["764d4886-919d-4fd2-bd4c-3dbc4b769cc2"] = [
{description: "<p>The application embeds the AOP Alliance library.<\/p>", ruleID: "embedded-framework-04700", issueName: "Embedded framework - AOP Alliance",
problemSummaryID: "764d4886-919d-4fd2-bd4c-3dbc4b769cc2", files: [
{l:"SUBTIC-Bloq.ear/lib/aopalliance-1.0.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("764d4886-919d-4fd2-bd4c-3dbc4b769cc2");