MIGRATION_ISSUES_DETAILS["c1ab3c5b-3af1-4dba-ae31-8a6b4cff6e94"] = [
{description: "<p>The application embeds a JFreeChart library.<\/p>", ruleID: "mvc-02700", issueName: "Embedded library - JFreeChart",
problemSummaryID: "c1ab3c5b-3af1-4dba-ae31-8a6b4cff6e94", files: [
{l:"SUBTIC-Bloq.ear/lib/jfreechart-1.0.12.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("c1ab3c5b-3af1-4dba-ae31-8a6b4cff6e94");