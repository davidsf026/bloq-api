MIGRATION_ISSUES_DETAILS["5e25b0b4-65e3-454f-9384-678168bde5b1"] = [
{description: "<p>The application embeds a Javax Inject library.<\/p>", ruleID: "embedded-framework-05300", issueName: "Embedded framework - Javax Inject",
problemSummaryID: "5e25b0b4-65e3-454f-9384-678168bde5b1", files: [
{l:"SUBTIC-Bloq.ear/lib/javax.inject-1.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("5e25b0b4-65e3-454f-9384-678168bde5b1");