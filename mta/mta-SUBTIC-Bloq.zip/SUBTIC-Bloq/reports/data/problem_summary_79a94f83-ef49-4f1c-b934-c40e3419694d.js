MIGRATION_ISSUES_DETAILS["79a94f83-ef49-4f1c-b934-c40e3419694d"] = [
{description: "<p>The changes that were implemented in JDK 9 may impact code that creates class loaders with null (that is, the bootstrap class loader) as the parent class loader and assumes that all platform classes are visible to the parent. Such code may need to be changed to use the platform class loader as the parent (see the links below)<\/p>", ruleID: "java-removals-00150", issueName: "Changes in ClassLoader hierarchy in JDK 11 may impact code",
problemSummaryID: "79a94f83-ef49-4f1c-b934-c40e3419694d", files: [
{l:"<a class='' href='ResourcesProperties_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.config.ResourcesProperties<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://docs.oracle.com/en/java/javase/11/migrate/index.html#JSMIG-GUID-A868D0B9-026F-4D46-B979-901834343F9E", t:"JDK11 New Classloader Implementations"},
{h:"https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/lang/ClassLoader.html#%3Cinit%3E(java.lang.ClassLoader)", t:"ClassLoader Constructor API"},
]},
];
onProblemSummaryLoaded("79a94f83-ef49-4f1c-b934-c40e3419694d");