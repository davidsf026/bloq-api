MIGRATION_ISSUES_DETAILS["d4c9c0b7-539f-4e99-9d4c-8451b09efb7a"] = [
{description: "<p>The application has a JSF library embedded.<\/p><p>Red Hat JBoss EAP includes JSF as a module with a version that has been tested and is supported by Red Hat. There are two options for using the JSF library:<\/p>\n<ol>\n <li>Keep it embedded as it is now. This approach is low effort but the application will not use a tested and supported library.<\/li>\n <li>Switch to use the JSF library in the EAP module. This will require effort to remove the embedded library and configure the application to use the module\'s library, but then the application will rely on a tested and supported version of the JSF library.<\/li>\n<\/ol><p>In the links below there are instructions to enable alternative versions for both EAP 6 and 7.<\/p>", ruleID: "embedded-framework-libraries-05000", issueName: "JSF embedded library",
problemSummaryID: "d4c9c0b7-539f-4e99-9d4c-8451b09efb7a", files: [
{l:"SUBTIC-Bloq.ear/lib/jsf-api-2.2.10.jar", oc:"1"},
{l:"SUBTIC-Bloq.ear/lib/jsf-impl-2.2.10.jar", oc:"1"},
], resourceLinks: [
{h:"https://access.redhat.com/articles/112673", t:"Red Hat JBoss EAP: Component Details"},
{h:"https://access.redhat.com/documentation/en-us/red_hat_jboss_enterprise_application_platform/7.0/html/migration_guide/application_migration_changes#migrate_jsf_code_changes", t:"Red Hat JBoss EAP 7: JavaServer Faces (JSF) Code Changes"},
{h:"https://access.redhat.com/solutions/2773121", t:"How to use JSF 1.2 with EAP 7?"},
{h:"https://access.redhat.com/documentation/en-us/red_hat_jboss_enterprise_application_platform/6.4/html-single/migration_guide/#sect-JSF_changes", t:"Red Hat JBoss EAP 6: JavaServer Faces (JSF) Code Changes"},
{h:"https://access.redhat.com/solutions/690953", t:"How to use JSF 1.2 with EAP 6"},
]},
];
onProblemSummaryLoaded("d4c9c0b7-539f-4e99-9d4c-8451b09efb7a");