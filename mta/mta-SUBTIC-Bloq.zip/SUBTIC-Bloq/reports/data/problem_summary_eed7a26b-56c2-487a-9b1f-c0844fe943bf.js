MIGRATION_ISSUES_DETAILS["eed7a26b-56c2-487a-9b1f-c0844fe943bf"] = [
{description: "<p>The application embeds the Spring framework.<\/p>", ruleID: "embedded-framework-90000", issueName: "Embedded framework - Spring",
problemSummaryID: "eed7a26b-56c2-487a-9b1f-c0844fe943bf", files: [
{l:"SUBTIC-Bloq.ear/lib/spring-expression-3.0.6.RELEASE.jar", oc:"1"},
{l:"SUBTIC-Bloq.ear/lib/spring-asm-3.0.6.RELEASE.jar", oc:"1"},
{l:"SUBTIC-Bloq.ear/lib/spring-context-3.0.6.RELEASE.jar", oc:"1"},
{l:"SUBTIC-Bloq.ear/lib/spring-aop-3.0.6.RELEASE.jar", oc:"1"},
{l:"SUBTIC-Bloq.ear/lib/spring-core-3.0.6.RELEASE.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("eed7a26b-56c2-487a-9b1f-c0844fe943bf");