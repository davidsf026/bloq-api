MIGRATION_ISSUES_DETAILS["1aa65862-a8b6-45e5-a87f-c3a63894c95b"] = [
{description: "<p><code>java.sql.DriverManager<\/code> type reference found. No specific details available.<\/p>", ruleID: "generic-catchall-00900", issueName: "java.sql.DriverManager type reference",
problemSummaryID: "1aa65862-a8b6-45e5-a87f-c3a63894c95b", files: [
{l:"<a class='' href='SSADriver_java.html?project=835592'>ssa.db.driver.SSADriver<\/a>", oc:"1"},
{l:"<a class='' href='XmlaOlap4jDriver_java.html?project=835592'>org.olap4j.driver.xmla.XmlaOlap4jDriver<\/a>", oc:"1"},
{l:"<a class='' href='SimpleQuerySample_java.html?project=835592'>org.olap4j.sample.SimpleQuerySample<\/a>", oc:"1"},
{l:"<a class='' href='DBExecuteDAO_java.html?project=835592'>br.gov.rj.fazenda.service.bdexecute.DBExecuteDAO<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("1aa65862-a8b6-45e5-a87f-c3a63894c95b");