MIGRATION_ISSUES_DETAILS["a4b6078a-8f36-4f13-b056-8041ed247ead"] = [
{description: "<p>The application embeds the Hamcrest library.<\/p>", ruleID: "test-frameworks-sauge-00050", issueName: "Embedded framework - Hamcrest",
problemSummaryID: "a4b6078a-8f36-4f13-b056-8041ed247ead", files: [
{l:"SUBTIC-Bloq.ear/lib/hamcrest-core-1.1.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("a4b6078a-8f36-4f13-b056-8041ed247ead");