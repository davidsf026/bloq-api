MIGRATION_ISSUES_DETAILS["3d629c08-c3a7-4d63-b57c-c0a0d745e994"] = [
{description: "<p>If the application writes logs to a file system, local log files may be lost if an instance terminates or restarts.<\/p><p>Recommendations<\/p>\n<ul>\n <li>Use a centralized log management system.<\/li>\n <li>Log to standard output and allow the cloud platform to manage the logging.<\/li>\n <li>Use shared storage for log files.<\/li>\n<\/ul>", ruleID: "logging-0000", issueName: "Logging to file system",
problemSummaryID: "3d629c08-c3a7-4d63-b57c-c0a0d745e994", files: [
{l:"<a class='' href='log4j_properties.71.html?project=835592'>WEB-INF/classes/log4j.properties<\/a>", oc:"2"},
{l:"<a class='' href='log4j_properties.html?project=835592'>log4j.properties<\/a>", oc:"2"},
{l:"<a class='' href='log4j_properties.21.html?project=835592'>log4j.properties<\/a>", oc:"2"},
], resourceLinks: [
{h:"https://12factor.net/logs", t:"Twelve-factor app - Logs"},
{h:"https://docs.openshift.com/container-platform/4.5/logging/cluster-logging.html", t:"OpenShift Container Platform: Understanding cluster logging"},
]},
];
onProblemSummaryLoaded("3d629c08-c3a7-4d63-b57c-c0a0d745e994");