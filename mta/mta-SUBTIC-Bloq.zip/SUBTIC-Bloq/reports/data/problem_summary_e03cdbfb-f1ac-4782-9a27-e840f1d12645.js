MIGRATION_ISSUES_DETAILS["e03cdbfb-f1ac-4782-9a27-e840f1d12645"] = [
{description: "<p>Replace the <code>javax.servlet<\/code> import statement with <code>jakarta.servlet<\/code><\/p>", ruleID: "javax-to-jakarta-import-00001", issueName: "javax.servlet has been replaced by jakarta.servlet",
problemSummaryID: "e03cdbfb-f1ac-4782-9a27-e840f1d12645", files: [
{l:"<a class='' href='LoginServlet_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.web.security.LoginServlet<\/a>", oc:"4"},
{l:"<a class='' href='LoginCertServlet_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.web.security.LoginCertServlet<\/a>", oc:"5"},
{l:"<a class='' href='LogoutServlet_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.web.security.LogoutServlet<\/a>", oc:"5"},
{l:"<a class='' href='HibernateContextListener_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.web.listener.HibernateContextListener<\/a>", oc:"2"},
{l:"<a class='' href='FiltroAutorizacao_java.html?project=835592'>ssa.control.servlet.FiltroAutorizacao<\/a>", oc:"10"},
{l:"<a class='' href='DesautorizadoTag_java.html?project=835592'>ssa.view.taglib.DesautorizadoTag<\/a>", oc:"1"},
{l:"<a class='' href='SSASessaoTag_java.html?project=835592'>ssa.view.taglib.SSASessaoTag<\/a>", oc:"2"},
{l:"<a class='' href='FiltroCertificado_java.html?project=835592'>ssa.control.servlet.FiltroCertificado<\/a>", oc:"9"},
{l:"<a class='' href='SSAPropertyTag_java.html?project=835592'>ssa.view.taglib.SSAPropertyTag<\/a>", oc:"2"},
{l:"<a class='' href='AutorizadoTag_java.html?project=835592'>ssa.view.taglib.AutorizadoTag<\/a>", oc:"3"},
{l:"<a class='' href='BloqueioFilter_java.html?project=835592'>br.gov.rj.fazenda.bloqueio.filtro.BloqueioFilter<\/a>", oc:"4"},
{l:"<a class='' href='HibernateFilter_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.model.util.HibernateFilter<\/a>", oc:"6"},
], resourceLinks: [
{h:"https://jakarta.ee/", t:"Jakarta EE"},
]},
];
onProblemSummaryLoaded("e03cdbfb-f1ac-4782-9a27-e840f1d12645");