MIGRATION_ISSUES_DETAILS["53877e5a-90df-42dd-823b-be514c36701d"] = [
{description: "<p>Replace the <code>javax.annotation<\/code> import statement with <code>jakarta.annotation<\/code><\/p>", ruleID: "javax-to-jakarta-import-00001", issueName: "javax.annotation has been replaced by jakarta.annotation",
problemSummaryID: "53877e5a-90df-42dd-823b-be514c36701d", files: [
{l:"<a class='' href='FuncionarioController_java.html?project=835592'>br.gov.rj.fazenda.bloqueio.controller.FuncionarioController<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://jakarta.ee/", t:"Jakarta EE"},
]},
];
onProblemSummaryLoaded("53877e5a-90df-42dd-823b-be514c36701d");