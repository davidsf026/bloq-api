MIGRATION_ISSUES_DETAILS["214eb313-b252-4228-baf2-d503efe37736"] = [
{description: "<p>Replace <code>web-app_3_1.xsd<\/code> with <code>web-app_5_0.xsd<\/code> and update the version attribute to <code>&quot;5.0&quot;<\/code><\/p>", ruleID: "javaee-to-jakarta-namespaces-00017", issueName: "Replace the Java EE XSD with the Jakarta equivalent",
problemSummaryID: "214eb313-b252-4228-baf2-d503efe37736", files: [
{l:"<a class='' href='web_xml.html?project=835592'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://jakarta.ee/xml/ns/jakartaee/#9", t:"Jakarta XML Schemas"},
]},
];
onProblemSummaryLoaded("214eb313-b252-4228-baf2-d503efe37736");