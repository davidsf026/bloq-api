MIGRATION_ISSUES_DETAILS["960f715b-1760-442d-92bd-40b3291e4dc2"] = [
{description: "<p>The application embeds a JSF library.<\/p>", ruleID: "mvc-01600", issueName: "Embedded library - JSF",
problemSummaryID: "960f715b-1760-442d-92bd-40b3291e4dc2", files: [
{l:"SUBTIC-Bloq.ear/lib/jsf-api-2.2.10.jar", oc:"1"},
{l:"SUBTIC-Bloq.ear/lib/jsf-impl-2.2.10.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("960f715b-1760-442d-92bd-40b3291e4dc2");