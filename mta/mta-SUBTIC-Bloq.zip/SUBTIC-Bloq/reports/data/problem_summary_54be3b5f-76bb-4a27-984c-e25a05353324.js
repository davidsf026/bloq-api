MIGRATION_ISSUES_DETAILS["54be3b5f-76bb-4a27-984c-e25a05353324"] = [
{description: "<p>Replace <code>http://xmlns.jcp.org/xml/ns/javaee<\/code> with <code>https://jakarta.ee/xml/ns/jakartaee<\/code> and change the schema version number<\/p>", ruleID: "javaee-to-jakarta-namespaces-00001", issueName: "Replace the Java EE namespace, schemaLocation and version with the Jakarta equivalent",
problemSummaryID: "54be3b5f-76bb-4a27-984c-e25a05353324", files: [
{l:"<a class='' href='web_xml.html?project=835592'>WEB-INF/web.xml<\/a>", oc:"3"},
{l:"<a class='' href='beans_xml.html?project=835592'>META-INF/beans.xml<\/a>", oc:"3"},
], resourceLinks: [
{h:"https://jakarta.ee/xml/ns/jakartaee/#10", t:"Jakarta EE XML Schemas"},
]},
];
onProblemSummaryLoaded("54be3b5f-76bb-4a27-984c-e25a05353324");