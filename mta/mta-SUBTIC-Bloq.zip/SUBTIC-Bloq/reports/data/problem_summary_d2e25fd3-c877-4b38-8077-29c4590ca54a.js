MIGRATION_ISSUES_DETAILS["d2e25fd3-c877-4b38-8077-29c4590ca54a"] = [
{description: "<p><code>web-app_3_1<\/code>: In the root tag, replace the <code>version<\/code> attribute value with <code>5.0<\/code><\/p>", ruleID: "javaee-to-jakarta-namespaces-00044", issueName: "Replace the Java EE version with the Jakarta equivalent",
problemSummaryID: "d2e25fd3-c877-4b38-8077-29c4590ca54a", files: [
{l:"<a class='' href='web_xml.html?project=835592'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://jakarta.ee/xml/ns/jakartaee/#9", t:"Jakarta XML Schemas"},
]},
];
onProblemSummaryLoaded("d2e25fd3-c877-4b38-8077-29c4590ca54a");