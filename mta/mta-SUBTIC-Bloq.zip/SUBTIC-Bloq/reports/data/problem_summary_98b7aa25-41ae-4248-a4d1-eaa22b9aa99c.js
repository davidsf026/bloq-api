MIGRATION_ISSUES_DETAILS["98b7aa25-41ae-4248-a4d1-eaa22b9aa99c"] = [
{description: "<p>The application embeds a Bouncy Castle library.<\/p>", ruleID: "security-02000", issueName: "Embedded library - Bouncy Castle",
problemSummaryID: "98b7aa25-41ae-4248-a4d1-eaa22b9aa99c", files: [
{l:"SUBTIC-Bloq.ear/lib/bcmail-jdk14-138.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("98b7aa25-41ae-4248-a4d1-eaa22b9aa99c");