MIGRATION_ISSUES_DETAILS["f3e2ba26-dd67-476f-9c57-85ffdf39a6d1"] = [
{description: "<p>The application embeds an Apache Log4J library.<\/p>", ruleID: "logging-usage-00010", issueName: "Embedded library - Apache Log4J",
problemSummaryID: "f3e2ba26-dd67-476f-9c57-85ffdf39a6d1", files: [
{l:"SUBTIC-Bloq.ear/lib/slf4j-log4j12-1.7.5.jar", oc:"1"},
{l:"SUBTIC-Bloq.ear/lib/log4j-1.2.17.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("f3e2ba26-dd67-476f-9c57-85ffdf39a6d1");