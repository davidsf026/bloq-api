MIGRATION_ISSUES_DETAILS["07329786-50f0-4c9a-a64c-1f19a1cda920"] = [
{description: "<p>This is an Oracle proprietary type (<code>oracle.jdbc.driver.OracleDriver<\/code>) and needs to be migrated to a compatible API. There is currently no detailed information about this type.<\/p>", ruleID: "weblogic-catchall-06000", issueName: "Oracle proprietary type reference",
problemSummaryID: "07329786-50f0-4c9a-a64c-1f19a1cda920", files: [
{l:"<a class='' href='SSADriver_java.html?project=835592'>ssa.db.driver.SSADriver<\/a>", oc:"2"},
], resourceLinks: [
]},
{description: "<p>This is an Oracle proprietary type (<code>oracle.jdbc.OracleDriver<\/code>) and needs to be migrated to a compatible API. There is currently no detailed information about this type.<\/p>", ruleID: "weblogic-catchall-06000", issueName: "Oracle proprietary type reference",
problemSummaryID: "07329786-50f0-4c9a-a64c-1f19a1cda920", files: [
{l:"<a class='' href='SSADriver_java.html?project=835592'>ssa.db.driver.SSADriver<\/a>", oc:"3"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("07329786-50f0-4c9a-a64c-1f19a1cda920");