MIGRATION_ISSUES_DETAILS["2bfe7764-1f81-435e-90e8-ad243cd42ee7"] = [
{description: "<p>Using ConsoleAppender configured in log4j.properties can cause a deadlock on JBoss EAP 6. It is recommended to Remove application level log4j ConsoleAppenders.<\/p>", ruleID: "log4j-03000", issueName: "Log4j ConsoleAppender Configuration - Potential Deadlock",
problemSummaryID: "2bfe7764-1f81-435e-90e8-ad243cd42ee7", files: [
{l:"<a class='' href='log4j_properties.71.html?project=835592'>WEB-INF/classes/log4j.properties<\/a>", oc:"1"},
{l:"<a class='' href='log4j_properties.html?project=835592'>log4j.properties<\/a>", oc:"1"},
{l:"<a class='' href='log4j_properties.21.html?project=835592'>log4j.properties<\/a>", oc:"2"},
], resourceLinks: [
{h:"https://access.redhat.com/solutions/375273", t:"EAP 6 deadlocks when using ConsoleHandler and java.io.PrintStream"},
]},
];
onProblemSummaryLoaded("2bfe7764-1f81-435e-90e8-ad243cd42ee7");