MIGRATION_ISSUES_DETAILS["99674602-60b1-41d7-a42b-dc55bc2c2b44"] = [
{description: "<p>An application running inside a container could lose access to a file in local storage.<\/p><p>Recommendations<\/p><p>The following recommendations depend on the function of the file in local storage:<\/p>\n<ul>\n <li>Logging: Log to standard output and use a centralized log collector to analyze the logs.<\/li>\n <li>Caching: Use a cache backing service.<\/li>\n <li>Configuration: Store configuration settings in environment variables so that they can be updated without code changes.<\/li>\n <li>Data storage: Use a database backing service for relational data or use a persistent data storage system.<\/li>\n <li>Temporary data storage: Use the file system of a running container as a brief, single-transaction cache.<\/li>\n<\/ul>", ruleID: "local-storage-00001", issueName: "File system - Java IO",
problemSummaryID: "99674602-60b1-41d7-a42b-dc55bc2c2b44", files: [
{l:"<a class='' href='VerificadorRevogacaoLocal_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.web.security.cert.VerificadorRevogacaoLocal<\/a>", oc:"2"},
{l:"<a class='' href='FileUtil_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.web.security.cert.util.FileUtil<\/a>", oc:"4"},
{l:"<a class='' href='VerificadorRevogacaoBase_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.web.security.cert.VerificadorRevogacaoBase<\/a>", oc:"5"},
{l:"<a class='' href='VerificadorRevogacaoBase_java.11.html?project=835592'>ssa.util.certificado.VerificadorRevogacaoBase<\/a>", oc:"5"},
{l:"<a class='' href='FileUtil_java.12.html?project=835592'>ssa.util.commons.FileUtil<\/a>", oc:"4"},
{l:"<a class='' href='Mensagem_java.html?project=835592'>ssa.control.servlet.Mensagem<\/a>", oc:"1"},
{l:"<a class='' href='VerificadorRevogacaoLocal_java.13.html?project=835592'>ssa.util.certificado.VerificadorRevogacaoLocal<\/a>", oc:"2"},
{l:"<a class='' href='Base64_java.html?project=835592'>org.olap4j.impl.Base64<\/a>", oc:"6"},
{l:"<a class='' href='XmlaOlap4jStatement_java.html?project=835592'>org.olap4j.driver.xmla.XmlaOlap4jStatement<\/a>", oc:"1"},
{l:"<a class='' href='SimpleQuerySample_java.html?project=835592'>org.olap4j.sample.SimpleQuerySample<\/a>", oc:"1"},
{l:"<a class='' href='XmlaOlap4jConnection_java.html?project=835592'>org.olap4j.driver.xmla.XmlaOlap4jConnection<\/a>", oc:"1"},
{l:"<a class='' href='SelectNode_java.html?project=835592'>org.olap4j.mdx.SelectNode<\/a>", oc:"1"},
{l:"<a class='' href='MdxUtil_java.html?project=835592'>org.olap4j.mdx.MdxUtil<\/a>", oc:"1"},
{l:"<a class='' href='HibernateUtil_java.html?project=835592'>br.gov.sefazrj.sati.sefazwork.model.util.HibernateUtil<\/a>", oc:"2"},
{l:"<a class='' href='ApplicationExternalProperties_java.html?project=835592'>br.gov.rj.fazenda.bloqueio.config.ApplicationExternalProperties<\/a>", oc:"3"},
], resourceLinks: [
{h:"https://12factor.net/config", t:"Twelve-Factor App: Config"},
{h:"https://docs.openshift.com/container-platform/4.5/logging/cluster-logging.html", t:"OpenShift Container Platform: Understanding cluster logging"},
{h:"https://docs.openshift.com/container-platform/4.5/storage/understanding-persistent-storage.html", t:"OpenShift Container Platform: Understanding persistent storage"},
{h:"https://12factor.net/logs", t:"Twelve-Factor App: Logs"},
{h:"https://12factor.net/backing-services", t:"Twelve-Factor App: Backing services"},
{h:"https://docs.openshift.com/container-platform/4.5/builds/creating-build-inputs.html#builds-input-secrets-configmaps_creating-build-inputs", t:"OpenShift Container Platform: Input secrets and ConfigMaps"},
]},
];
onProblemSummaryLoaded("99674602-60b1-41d7-a42b-dc55bc2c2b44");