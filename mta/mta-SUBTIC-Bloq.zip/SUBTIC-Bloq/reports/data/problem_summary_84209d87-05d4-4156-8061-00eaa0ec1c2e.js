MIGRATION_ISSUES_DETAILS["84209d87-05d4-4156-8061-00eaa0ec1c2e"] = [
{description: "<p>The application embeds an Apache Commons Logging library.<\/p>", ruleID: "logging-usage-00020", issueName: "Embedded library - Apache Commons Logging",
problemSummaryID: "84209d87-05d4-4156-8061-00eaa0ec1c2e", files: [
{l:"SUBTIC-Bloq.ear/lib/commons-logging-1.1.1.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("84209d87-05d4-4156-8061-00eaa0ec1c2e");